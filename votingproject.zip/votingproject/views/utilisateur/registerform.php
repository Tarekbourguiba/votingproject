<div class="page-title">
    <h1 class="title">Page de connexion</h1>
</div>
      <div class="content">       
        <form id="form" name="form" method="post" action="<?php echo url_for('utilisateur','register'); ?>" >
     ici form register
        </form>
    </div>
                                    