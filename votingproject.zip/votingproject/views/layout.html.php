<!DOCTYPE html>
<html lang="en">
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Voting project</title>
    <meta name="description"  content="application web de vote" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="assets/css/style.css" rel="stylesheet" />
    
  </head>
  
<body >

    <div class="container">
     
    <?php echo $content; ?>

    </div>


   
      <footer>
        <p>&copy; open source</p>
      </footer>
  </body>
</html>
